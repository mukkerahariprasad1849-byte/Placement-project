package snippet;

public class Snippet {
	public static void main(String[] args) {
		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
	}
}

